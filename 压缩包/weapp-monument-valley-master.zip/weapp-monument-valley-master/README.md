## 纪念碑谷 小程序

### 1、安装

   * 克隆代码, 导入开发者工具

   ![](http://iat-net-cn.qiniudn.com/weapp-monument-valley-0.png)
   
   
### 2、运行

   ![](http://iat-net-cn.qiniudn.com/weapp-monument-valley-2.png)
